⤚⟶ License ⟵⤙

- 1. You may modify the assets.

Feel free to create your own sprites in this style or use them as reference for your own artwork.
Making additional sprites in the same style or adapting them for your project is also allowed.
 
⤚⟶------⟵⤙

 - 2. You may use these assets in any kind of non-commercial project.

Use in anything related to NFTs or AI training is strictly prohibited.
The author of the assets is not directly affiliated with any projects using them

⤚⟶------⟵⤙

 - 3. You may not redistribute or resell the asset pack itself, even in modified form.

You are allowed to share your own projects (games, software, etc.) that use these assets.
Open-source projects are allowed — in that case, please include a note stating that some or all assets were created by Jaraten, along with the applicable license terms.

⤚⟶------⟵⤙

 - 4. Credit is required : (Jaraten) 

 Credit example : Forgotten-marshes asset-pack by Jaraten
 If you share your game on itch.io a link to the Asset Packs page would be very appreciated.
 If you have questions or need/want different licensing terms please reach out to me and I can work with you on a license that suits your needs.
 
⤚⟶  Info  ⟵⤙

Heyo. Thanks for downloading the Forgotten-Marshes pack.
 - Made by : Jaraten 

 - Discord : jaraten 
 - Twitter : https://x.com/klifvv
 - Website : https://jaraten.carrd.co/

   If you want to follow my work further, go to my discord server or twitter.

⤚⟶  Support  ⟵⤙
 
If you enjoy this asset pack consider leaving a rating and a comment. 
It really helps to support the future of this project.

If you wish, you can purchase a subscription to my boosty:
https://boosty.to/klifvv

